package com.example.demo.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Controller;

@Controller
@Path("/service")
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class HelloResource {

	@GET
	@Path("/hello")
	@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
	public Response hello()
	{
	String doc="Hellow";
	return Response.status(200).entity(doc).build();
	}
}
